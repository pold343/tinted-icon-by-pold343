#!/usr/bin/env python3
"""
icon_tint.py - перекрашивает ВСЕ иконки текущей темы в один цвет
(аналог "tinted icons" в macOS/iOS). Работает на Fedora и Debian/Ubuntu.

Зависимости:
  Debian/Ubuntu:  sudo apt install python3-pil python3-tk
  Fedora:         sudo dnf install python3-pillow python3-tkinter

Использование:
  ./icon_tint.py                      # откроется палитра, выбираете цвет
  ./icon_tint.py --color "#e8590c"    # без окна
  ./icon_tint.py --color "#e8590c" --widgets   # + акцент кнопок/виджетов GTK
  ./icon_tint.py --source Papirus     # взять другую тему за основу
  ./icon_tint.py --restore            # вернуть всё как было
"""
import argparse
import configparser
import gzip
import os
import re
import shutil
import subprocess
import sys
from multiprocessing import Pool

try:
    from PIL import Image, ImageOps
except ImportError:
    sys.exit("Нужен Pillow: sudo apt install python3-pil  |  sudo dnf install python3-pillow")

HOME = os.path.expanduser("~")
OUT_ROOT = os.path.join(HOME, ".local/share/icons")
STATE_DIR = os.path.join(HOME, ".config/icon-tint")
SEARCH = [OUT_ROOT, os.path.join(HOME, ".icons"),
          "/usr/local/share/icons", "/usr/share/icons"]
MARK_A, MARK_B = "/* ICON-TINT-START */", "/* ICON-TINT-END */"


# ---------- цвет ----------
def hex_to_rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_to_hex(c):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in c)


def mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def ramp(tint):
    """тёмный -> основной -> светлый оттенок выбранного цвета"""
    return mix((0, 0, 0), tint, 0.30), tint, mix(tint, (255, 255, 255), 0.85)


def map_color(rgb, tint):
    dark, mid, light = ramp(tint)
    g = (0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]) / 255
    return mix(dark, mid, g * 2) if g < 0.5 else mix(mid, light, (g - 0.5) * 2)


# ---------- обработка файлов ----------
HEX_RE = re.compile(r"(?<![\w(&])#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b")
NAMED_RE = re.compile(r"(fill|stroke|stop-color|color)(=[\"']|:\s*)(white|black)\b")


def tint_svg_text(text, tint, symbolic):
    def hex_sub(m):
        rgb = hex_to_rgb(m.group(1))
        return rgb_to_hex(tint if symbolic else map_color(rgb, tint))

    def named_sub(m):
        rgb = (255, 255, 255) if m.group(3) == "white" else (0, 0, 0)
        new = tint if symbolic else map_color(rgb, tint)
        return m.group(1) + m.group(2) + rgb_to_hex(new)

    return NAMED_RE.sub(named_sub, HEX_RE.sub(hex_sub, text))


def tint_png(src, dst, tint, symbolic):
    img = Image.open(src).convert("RGBA")
    r, g, b, a = img.split()
    if symbolic:
        out = Image.new("RGB", img.size, tuple(int(v) for v in tint))
    else:
        dark, mid, light = ramp(tint)
        gray = ImageOps.grayscale(Image.merge("RGB", (r, g, b)))
        out = ImageOps.colorize(gray, black=tuple(int(v) for v in dark),
                                white=tuple(int(v) for v in light),
                                mid=tuple(int(v) for v in mid))
    out = out.convert("RGBA")
    out.putalpha(a)
    out.save(dst, "PNG")


def process(task):
    src, dst, tint, symbolic = task
    try:
        low = src.lower()
        if low.endswith(".png"):
            tint_png(src, dst, tint, symbolic)
        elif low.endswith(".svg"):
            with open(src, encoding="utf-8", errors="ignore") as f:
                data = f.read()
            with open(dst, "w", encoding="utf-8") as f:
                f.write(tint_svg_text(data, tint, symbolic))
        elif low.endswith(".svgz"):
            with gzip.open(src, "rt", encoding="utf-8", errors="ignore") as f:
                data = f.read()
            with gzip.open(dst, "wt", encoding="utf-8") as f:
                f.write(tint_svg_text(data, tint, symbolic))
        else:
            shutil.copy2(src, dst)
    except Exception:
        try:
            shutil.copy2(src, dst)
        except Exception:
            pass


# ---------- темы ----------
def find_theme(name):
    for base in SEARCH:
        p = os.path.join(base, name)
        if os.path.isfile(os.path.join(p, "index.theme")):
            return p
    return None


def read_inherits(path):
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    try:
        cp.read(os.path.join(path, "index.theme"), encoding="utf-8")
        val = cp.get("Icon Theme", "Inherits", fallback="")
    except Exception:
        val = ""
    return [x.strip() for x in val.split(",") if x.strip()]


def build_chain(name):
    chain, queue = [], [name]
    while queue:
        n = queue.pop(0)
        if n in chain or n.lower() == "hicolor":
            continue
        p = find_theme(n)
        if p:
            chain.append(n)
            queue.extend(read_inherits(p))
    chain.append("hicolor")
    return chain


def sh(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True).stdout.strip()
    except Exception:
        return ""


def current_theme():
    out = sh(["gsettings", "get", "org.gnome.desktop.interface", "icon-theme"])
    return out.strip("'\"") or "Adwaita"


def write_index(src, dst, orig, tinted, chain_map=None):
    with open(os.path.join(src, "index.theme"), encoding="utf-8", errors="ignore") as f:
        lines = f.read().splitlines()
    out, seen_inh = [], False
    for ln in lines:
        if ln.startswith("Name="):
            out.append("Name=" + tinted)
        elif ln.startswith("Inherits="):
            seen_inh = True
            out.append("Inherits=" + ",".join(chain_map or []))
        else:
            out.append(ln)
    if not seen_inh:
        for i, ln in enumerate(out):
            if ln.strip() == "[Icon Theme]":
                out.insert(i + 1, "Inherits=" + ",".join(chain_map or []))
                break
    with open(os.path.join(dst, "index.theme"), "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")


def apply_icon_theme(name):
    sh(["gsettings", "set", "org.gnome.desktop.interface", "icon-theme", name])
    for kw in ("kwriteconfig6", "kwriteconfig5"):
        if shutil.which(kw):
            sh([kw, "--file", "kdeglobals", "--group", "Icons", "--key", "Theme", name])
            break


# ---------- виджеты GTK ----------
def css_block(tint):
    hx = rgb_to_hex(tint)
    light = rgb_to_hex(mix(tint, (255, 255, 255), 0.35))
    lum = (0.299 * tint[0] + 0.587 * tint[1] + 0.114 * tint[2]) / 255
    fg = "#ffffff" if lum < 0.6 else "#1a1a1a"
    return (f"{MARK_A}\n"
            f"@define-color accent_bg_color {hx};\n"
            f"@define-color accent_color {light};\n"
            f"@define-color accent_fg_color {fg};\n"
            f"@define-color theme_selected_bg_color {hx};\n"
            f"@define-color theme_selected_fg_color {fg};\n"
            f"{MARK_B}\n")


def strip_block(text):
    return re.sub(re.escape(MARK_A) + r".*?" + re.escape(MARK_B) + r"\n?", "", text, flags=re.S)


def edit_gtk_css(tint=None):
    for v in ("gtk-3.0", "gtk-4.0"):
        d = os.path.join(HOME, ".config", v)
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "gtk.css")
        old = open(p, encoding="utf-8").read() if os.path.exists(p) else ""
        new = strip_block(old)
        if tint:
            new += ("\n" if new and not new.endswith("\n") else "") + css_block(tint)
        with open(p, "w", encoding="utf-8") as f:
            f.write(new)


# ---------- выбор цвета (красивый диалог) ----------
def _rrect(c, x1, y1, x2, y2, r, **kw):
    r = max(1, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
           x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(pts, smooth=True, **kw)


def _remove_decorations(root):
    """Просим оконный менеджер не рисовать рамку (X11/XWayland), фокус клавиатуры остаётся."""
    try:
        wid = int(root.wm_frame(), 16)
    except Exception:
        return False
    try:
        import ctypes
        import ctypes.util
        lib = ctypes.util.find_library("X11")
        x11 = ctypes.CDLL(lib)
        x11.XOpenDisplay.restype = ctypes.c_void_p
        x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
        x11.XInternAtom.restype = ctypes.c_ulong
        x11.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
        x11.XChangeProperty.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong,
                                        ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
                                        ctypes.c_void_p, ctypes.c_int]
        x11.XFlush.argtypes = [ctypes.c_void_p]
        x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
        dpy = x11.XOpenDisplay(None)
        if dpy:
            atom = x11.XInternAtom(dpy, b"_MOTIF_WM_HINTS", 0)
            data = (ctypes.c_ulong * 5)(2, 0, 0, 0, 0)  # decorations = 0
            x11.XChangeProperty(dpy, wid, atom, atom, 32, 0, data, 5)
            x11.XFlush(dpy)
            x11.XCloseDisplay(dpy)
            return True
    except Exception:
        pass
    if shutil.which("xprop"):
        r = subprocess.run(["xprop", "-id", hex(wid), "-f", "_MOTIF_WM_HINTS", "32c",
                            "-set", "_MOTIF_WM_HINTS", "2, 0, 0, 0, 0"])
        return r.returncode == 0
    return False


def _decorated(root):
    """True, если оконный менеджер всё ещё рисует заголовок."""
    root.update()
    return root.winfo_rooty() - root.winfo_y() > 4


def _make_frameless(root):
    """Убираем системный заголовок по очереди разными способами, проверяя результат."""
    root.withdraw()
    root.update_idletasks()
    _remove_decorations(root)          # 1) подсказка _MOTIF_WM_HINTS
    root.deiconify()
    if not _decorated(root):
        return
    root.withdraw()                    # 2) тип окна "splash" (без рамки)
    try:
        root.attributes("-type", "splash")
    except Exception:
        pass
    root.deiconify()
    if not _decorated(root):
        return
    root.withdraw()                    # 3) окно вообще без участия менеджера
    root.overrideredirect(True)
    root.deiconify()
    root.update()
    root.focus_force()


def _custom_picker(initial, frameless):
    import tkinter as tk
    from tkinter import font as tkfont

    CARD, INK, MUTED = "#fafafc", "#1c1c1e", "#8e8e93"
    BG = CARD
    LINE, BORDER = "#e6e6ea", "#dedee3"
    k, ox, oy, M = 0.42, 72, 81, 0
    W, H = 613, 326

    def X(x):
        return (x - ox) * k + M

    def Y(y):
        return (y - oy) * k + M

    root = tk.Tk()
    root.title("Выберите цвет для иконок")
    root.configure(bg=BG)
    root.resizable(False, False)
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{W}x{H}+{(sw - W) // 2}+{(sh - H) // 2}")

    fams = set(tkfont.families())
    fam = next((f for f in ("Manrope", "Inter", "Onest", "Cantarell", "Noto Sans",
                            "Ubuntu", "DejaVu Sans") if f in fams), "sans-serif")

    def F(size, bold=False):
        return (fam, -size, "bold" if bold else "normal")

    c = tk.Canvas(root, width=W, height=H, bg=BG, highlightthickness=0, bd=0)
    c.pack()
    if frameless:
        _make_frameless(root)

    vals = [217, 217, 217]
    result = [None]

    # карточка
    _rrect(c, M, M, W - M, H - M, 25, fill=CARD, outline="")

    # шапка
    c.create_text(X(132), Y(142), text="Выберите цвет для иконок", anchor="w",
                  font=F(23, True), fill=INK)
    c.create_text(X(1485), Y(142), text="by pold343", anchor="e",
                  font=F(21, True), fill=MUTED)
    c.create_line(X(72), Y(198), X(1531), Y(198), fill=LINE)

    # ряды ползунков
    names = ["Красный:", "Зелёный:", "Голубой:"]
    centers = [293, 411, 530]
    rows = []
    for i in range(3):
        cy = centers[i]
        c.create_text(X(132), Y(cy), text=names[i], anchor="w", font=F(19), fill=INK)
        bx1, bx2, by1, by2 = X(347), X(460), Y(cy - 40), Y(cy + 40)
        _rrect(c, bx1, by1, bx2, by2, 9, fill="#ffffff", outline=BORDER)
        e = tk.Entry(root, bd=0, justify="center", font=F(19), bg="#ffffff", fg=INK,
                     insertbackground=INK, highlightthickness=0, relief="flat")
        c.create_window((bx1 + bx2) / 2, (by1 + by2) / 2, window=e,
                        width=int(bx2 - bx1 - 10), height=int(by2 - by1 - 10))
        tx1, tx2, ty1, ty2 = X(485), X(1046), Y(cy - 32), Y(cy + 32)
        r = 9
        n = int(tx2 - tx1)
        items = []
        for j in range(n):
            if j < r:
                dx = r - j - 0.5
                inset = r - (r * r - dx * dx) ** 0.5
            elif j >= n - r:
                dx = j - (n - r) + 0.5
                inset = r - (r * r - dx * dx) ** 0.5
            else:
                inset = 0
            items.append(c.create_line(tx1 + j, ty1 + inset, tx1 + j, ty2 - inset,
                                       fill="#cccccc"))
        _rrect(c, tx1, ty1, tx2, ty2, r, fill="", outline="#d6d6dc")
        marker = c.create_polygon(0, 0, 0, 0, 0, 0, fill=INK, outline=INK)
        rows.append(dict(entry=e, items=items, marker=marker,
                         tx1=tx1, tx2=tx2, ty1=ty1, ty2=ty2, n=n))

    # разделитель + выбранный цвет
    c.create_line(X(1086), Y(238), X(1086), Y(617), fill=LINE)
    c.create_text(X(1127), Y(267), text="Selection:", anchor="w", font=F(20, True), fill=INK)
    hx1, hx2, hy1, hy2 = X(1127), X(1481), Y(307), Y(384)
    _rrect(c, hx1, hy1, hx2, hy2, 9, fill="#f5f5f7", outline=BORDER)
    hex_e = tk.Entry(root, bd=0, font=F(19), bg="#f5f5f7", fg=INK,
                     insertbackground=INK, highlightthickness=0, relief="flat")
    c.create_window(hx1 + 8, (hy1 + hy2) / 2, window=hex_e, anchor="w",
                    width=int(hx2 - hx1 - 20), height=int(hy2 - hy1 - 12))
    swatch = _rrect(c, X(1127), Y(410), X(1481), Y(600), 9, fill="#d9d9d9", outline="")

    # кнопки
    c.create_line(X(95), Y(687), X(1509), Y(687), fill=LINE)
    ok_box = (X(207), Y(722), X(709), Y(821))
    cn_box = (X(946), Y(722), X(1442), Y(821))
    ok_bg = _rrect(c, *ok_box, 17, fill="#f7f7f9", outline="#b9b9c2", width=1.5)
    cn_bg = _rrect(c, *cn_box, 17, fill="#ececf0", outline="")
    c.create_text((ok_box[0] + ok_box[2]) / 2, (ok_box[1] + ok_box[3]) / 2,
                  text="OK", font=F(20, True), fill=INK)
    c.create_text((cn_box[0] + cn_box[2]) / 2, (cn_box[1] + cn_box[3]) / 2,
                  text="Отмена", font=F(20, True), fill="#5a5a60")

    # ---- логика ----
    def cur_hex():
        return "#%02x%02x%02x" % tuple(vals)

    def update(skip=None):
        for i, row in enumerate(rows):
            for j, it in enumerate(row["items"]):
                v = round(j / max(1, row["n"] - 1) * 255)
                rgb = list(vals)
                rgb[i] = v
                c.itemconfig(it, fill="#%02x%02x%02x" % tuple(rgb))
            mx = row["tx1"] + vals[i] / 255 * (row["tx2"] - row["tx1"])
            top = row["ty2"] + 4
            c.coords(row["marker"], mx, top, mx - 6, top + 11, mx + 6, top + 11)
            if skip != i:
                row["entry"].delete(0, "end")
                row["entry"].insert(0, str(vals[i]))
        c.itemconfig(swatch, fill=cur_hex())
        if skip != "hex":
            hex_e.delete(0, "end")
            hex_e.insert(0, cur_hex())

    def entry_edit(i):
        def handler(_e=None):
            t = rows[i]["entry"].get().strip()
            if t.isdigit():
                vals[i] = max(0, min(255, int(t)))
                update(skip=i)
        return handler

    for i, row in enumerate(rows):
        row["entry"].bind("<KeyRelease>", entry_edit(i))

    def hex_edit(_e=None):
        t = hex_e.get().strip().lstrip("#")
        if re.fullmatch(r"[0-9a-fA-F]{6}", t):
            vals[:] = list(hex_to_rgb(t))
            update(skip="hex")

    hex_e.bind("<KeyRelease>", hex_edit)

    def finish(ok):
        result[0] = cur_hex() if ok else None
        root.destroy()

    state = {"slider": None, "drag": None}

    def inside(b, x, y):
        return b[0] <= x <= b[2] and b[1] <= y <= b[3]

    def set_from_x(i, x):
        row = rows[i]
        t = (x - row["tx1"]) / (row["tx2"] - row["tx1"])
        vals[i] = max(0, min(255, int(round(t * 255))))
        update()

    def press(ev):
        root.focus_set()
        if inside(ok_box, ev.x, ev.y):
            return finish(True)
        if inside(cn_box, ev.x, ev.y):
            return finish(False)
        for i, row in enumerate(rows):
            if row["tx1"] - 8 <= ev.x <= row["tx2"] + 8 and row["ty1"] - 4 <= ev.y <= row["ty2"] + 18:
                state["slider"] = i
                return set_from_x(i, ev.x)
        if ev.y < Y(198):
            state["drag"] = (ev.x_root - root.winfo_x(), ev.y_root - root.winfo_y())

    def motion(ev):
        if state["slider"] is not None:
            set_from_x(state["slider"], ev.x)
        elif state["drag"]:
            root.geometry(f"+{ev.x_root - state['drag'][0]}+{ev.y_root - state['drag'][1]}")

    def release(_ev):
        state["slider"] = state["drag"] = None

    def hover(ev):
        on_btn = inside(ok_box, ev.x, ev.y) or inside(cn_box, ev.x, ev.y)
        on_btn = on_btn or any(r["tx1"] <= ev.x <= r["tx2"] and r["ty1"] <= ev.y <= r["ty2"] for r in rows)
        c.config(cursor="hand2" if on_btn else "")
        c.itemconfig(ok_bg, fill="#eeeef2" if inside(ok_box, ev.x, ev.y) else "#f7f7f9")
        c.itemconfig(cn_bg, fill="#e2e2e8" if inside(cn_box, ev.x, ev.y) else "#ececf0")

    c.bind("<Button-1>", press)
    c.bind("<B1-Motion>", motion)
    c.bind("<ButtonRelease-1>", release)
    c.bind("<Motion>", hover)
    root.bind("<Escape>", lambda e: finish(False))
    root.bind("<Return>", lambda e: finish(True))

    try:
        vals[:] = list(hex_to_rgb(initial))
    except Exception:
        pass
    update()
    root.after(150, root.focus_force)
    root.mainloop()
    return result[0]


def pick_color(frameless=False):
    try:
        return _custom_picker("#d9d9d9", frameless)
    except Exception as e:
        print("Не удалось открыть свой диалог:", e)
    try:
        import tkinter
        from tkinter import colorchooser
        root = tkinter.Tk()
        root.withdraw()
        c = colorchooser.askcolor(title="Выберите цвет для иконок")[1]
        root.destroy()
        if c:
            return c
    except Exception:
        pass
    return input("Введите цвет (например #e8590c): ").strip()


# ---------- main ----------
EXTRA_HICOLOR = [
    "/var/lib/flatpak/exports/share/icons/hicolor",
    os.path.join(HOME, ".local/share/flatpak/exports/share/icons/hicolor"),
    os.path.join(HOME, ".local/share/icons/hicolor"),
    "/var/lib/snapd/desktop/icons/hicolor",
]


def tint_extra_hicolor(dst, tint, pool):
    """иконки Flatpak/пользовательских приложений -> в покрашенный hicolor"""
    tasks = []
    for src in EXTRA_HICOLOR:
        if not os.path.isdir(src):
            continue
        for root, _d, files in os.walk(src):
            rel = os.path.relpath(root, src)
            for f in files:
                if not f.lower().endswith((".png", ".svg", ".svgz")):
                    continue
                s = os.path.join(root, f)
                real = os.path.realpath(s)  # у Flatpak это симлинки
                if not os.path.isfile(real):
                    continue
                out_dir = os.path.join(dst, rel)
                os.makedirs(out_dir, exist_ok=True)
                d = os.path.join(out_dir, f)
                if os.path.lexists(d):
                    os.remove(d)
                tasks.append((real, d, tint, "-symbolic" in f.lower()))
    for _ in pool.imap_unordered(process, tasks, chunksize=64):
        pass
    print(f"Доп. иконок (Flatpak и т.п.): {len(tasks)}")


def main():
    ap = argparse.ArgumentParser(description="Перекрасить все иконки в один цвет")
    ap.add_argument("--color", help="цвет в формате #rrggbb")
    ap.add_argument("--source", help="тема-основа (по умолчанию текущая)")
    ap.add_argument("--widgets", action="store_true", help="перекрасить акцент виджетов GTK")
    ap.add_argument("--frameless", action="store_true",
                    help="окно без системного заголовка (на некоторых системах не работает ввод с клавиатуры)")
    ap.add_argument("--restore", action="store_true", help="вернуть исходную тему")
    args = ap.parse_args()

    os.makedirs(STATE_DIR, exist_ok=True)
    state = os.path.join(STATE_DIR, "original")

    if args.restore:
        if os.path.exists(state):
            apply_icon_theme(open(state).read().strip())
        edit_gtk_css(None)
        for d in os.listdir(OUT_ROOT) if os.path.isdir(OUT_ROOT) else []:
            if d.startswith("Tinted-"):
                shutil.rmtree(os.path.join(OUT_ROOT, d), ignore_errors=True)
        print("Готово, всё возвращено.")
        return

    color = args.color or pick_color(frameless=args.frameless)
    if not re.fullmatch(r"#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", color or ""):
        sys.exit("Неверный цвет, нужен формат #rrggbb")
    tint = hex_to_rgb(color)
    tag = rgb_to_hex(tint).lstrip("#")

    source = args.source or current_theme()
    if source.startswith("Tinted-"):  # не красим уже покрашенное
        source = open(state).read().strip() if os.path.exists(state) else "Adwaita"
    elif not os.path.exists(state):
        open(state, "w").write(source)
    chain = build_chain(source)
    print("Цепочка тем:", " -> ".join(chain))

    names = {n: f"Tinted-{n}-{tag}" for n in chain}
    os.makedirs(OUT_ROOT, exist_ok=True)
    with Pool() as pool:
        for i, n in enumerate(chain):
            src = find_theme(n)
            if not src:
                continue
            print(f"Крашу {n} ...")
            dst = os.path.join(OUT_ROOT, names[n])
            shutil.rmtree(dst, ignore_errors=True)
            tasks = []
            for root, _dirs, files in os.walk(src):
                rel = os.path.relpath(root, src)
                os.makedirs(os.path.join(dst, rel), exist_ok=True)
                for f in files:
                    if f == "index.theme" or f.startswith("icon-theme.cache"):
                        continue
                    s, d = os.path.join(root, f), os.path.join(dst, rel, f)
                    if os.path.islink(s):
                        t = os.readlink(s)
                        if t.startswith(src):
                            t = t.replace(src, dst, 1)
                        try:
                            os.symlink(t, d)
                        except OSError:
                            pass
                    else:
                        tasks.append((s, d, tint, "-symbolic" in f.lower()))
            for _ in pool.imap_unordered(process, tasks, chunksize=64):
                pass
            parents = [names[p] for p in chain[i + 1:i + 2]]
            write_index(src, dst, n, names[n], parents)
            if shutil.which("gtk-update-icon-cache"):
                subprocess.run(["gtk-update-icon-cache", "-q", "-f", "-t", dst])

        hic = os.path.join(OUT_ROOT, names["hicolor"])
        if os.path.isdir(hic):
            print("Крашу иконки Flatpak/пользовательские ...")
            tint_extra_hicolor(hic, tint, pool)
            if shutil.which("gtk-update-icon-cache"):
                subprocess.run(["gtk-update-icon-cache", "-q", "-f", "-t", hic])

    apply_icon_theme(names[chain[0]])
    if args.widgets:
        edit_gtk_css(tint)
    print(f"\nГотово! Тема: {names[chain[0]]}")
    print("Если что-то не обновилось — перезапустите приложения или перелогиньтесь.")


if __name__ == "__main__":
    main()
