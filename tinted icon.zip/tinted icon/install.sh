#!/usr/bin/env bash
# Установщик "tinted icon": зависимости + копия программы + ярлыки в меню.
# Работает на Fedora и Debian/Ubuntu.
#
#   ./install.sh              установить
#   ./install.sh --uninstall  удалить программу и ярлыки

set -e

APP_NAME="tinted icon"
APP_DIR="$HOME/.local/share/icon-tint"
DESKTOP_DIR="$HOME/.local/share/applications"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$1" = "--uninstall" ]; then
    rm -rf "$APP_DIR"
    rm -f "$DESKTOP_DIR/icon-tint.desktop" "$DESKTOP_DIR/icon-tint-restore.desktop"
    update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
    echo "Удалено. Покрашенные темы в ~/.local/share/icons/Tinted-* и настройки"
    echo "можно вернуть командой: python3 icon_tint.py --restore (до удаления)."
    exit 0
fi

if [ ! -f "$SRC_DIR/icon_tint.py" ]; then
    echo "Не найден icon_tint.py рядом с install.sh"
    exit 1
fi

# --- 1. зависимости ---
if python3 -c "import PIL, tkinter" 2>/dev/null; then
    echo "[1/3] Зависимости уже установлены"
else
    echo "[1/3] Ставлю зависимости (понадобится пароль sudo)..."
    if command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y python3 python3-pillow python3-tkinter
    elif command -v apt >/dev/null 2>&1; then
        sudo apt update
        sudo apt install -y python3 python3-pil python3-tk
    else
        echo "Не знаю ваш пакетный менеджер. Поставьте вручную: Pillow и Tkinter для Python 3."
        exit 1
    fi
fi

# --- 2. копирование программы ---
echo "[2/3] Копирую программу в $APP_DIR"
mkdir -p "$APP_DIR" "$DESKTOP_DIR"
cp "$SRC_DIR/icon_tint.py" "$APP_DIR/icon_tint.py"
chmod +x "$APP_DIR/icon_tint.py"

# --- 3. ярлыки ---
echo "[3/3] Создаю ярлыки в меню"
cat > "$DESKTOP_DIR/icon-tint.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=$APP_NAME
Comment=Перекрасить все иконки в один цвет
Exec=python3 "$APP_DIR/icon_tint.py"
Icon=preferences-color
Terminal=false
Categories=Utility;Settings;
EOF

cat > "$DESKTOP_DIR/icon-tint-restore.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=$APP_NAME: вернуть как было
Comment=Вернуть исходные иконки
Exec=python3 "$APP_DIR/icon_tint.py" --restore
Icon=edit-undo
Terminal=false
Categories=Utility;Settings;
EOF

update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true

echo
echo "Готово! Нажмите Super и начните печатать: tinted icon"
echo "Папку с установщиком теперь можно двигать или удалять."
